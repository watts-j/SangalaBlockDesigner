THE BOW, FOR SANGALA BLOCKS
LEGO design 93273 - Brick, Modified 1 x 4 x 2/3, Double Curved Top, No Studs
Prepared 2026-08-27


WHAT IS IN HERE

  Bow.library                             the part, as a library Sangala Blocks can open
  LDraw\ldraw\parts\93273.dat             its geometry
  LDraw\ldraw\parts\s\93273s01.dat        a sub-part 93273 is built from


WHAT TO DO WITH IT

  1. Copy the two .dat files into your own LDraw folder, keeping the folders they
     are in - 93273.dat beside the other parts, 93273s01.dat in the "s" folder
     beside them. The paths above are laid out to match, so copying the LDraw
     folder over your own puts both in the right place.

     Every other file the bow needs - the cylinders and edges it is drawn from -
     is already in your LDraw folder. Only these two are new.

  2. Open Sangala Blocks and choose Open, then Bow.library. A "Bow" button
     appears on the Part menu.


WHAT THE FILE SAYS

  {
   "id": "93273",                          the number you order by
   "name": "Slope Brick Curved 4 x 1 Double",   LDraw's own name for it
   "kind": "bow",                          the bin it belongs in
   "w": 4, "d": 1,                         four studs long, one deep
   "h": 2,                                 two plates tall - LEGO's "2/3" of a brick
   "shape": "bow",                         how the page should draw it
   "label": "Bow",                         what its button should read
   "studs": false                          it has none on top
  }

  Every measurement was read from the LDraw file itself, not typed.


WHAT YOUR VERSION WILL DO WITH IT, AND WHAT IT WILL NOT

  These were checked by running your own copy's drawing code against the part,
  not guessed at.

  The 3D view will be right. It reads the geometry directly, so the bow appears
  as the curved piece it is.

  The workspace will draw it as a plain rounded rectangle, four studs by one,
  rather than showing the curve. Your copy folds a part's studs flat by clamping
  its geometry at the origin plane, which assumes a part's body hangs BELOW its
  origin. 93273 is built the other way up - all of its geometry sits at or above
  the origin - so the fold flattens the whole part and the outline comes out with
  no height, and the page falls back to a plain shape.

  It will be drawn WITH STUDS ON TOP, and the real part has none. "studs": false
  is only read for a part dragged from a kit in your copy, not for one in a
  library.

  It will sit at the BOTTOM of the Part menu, after Wedge Plate, and its button
  will carry a small square rather than an icon of its own.

  None of that harms the design or the parts list: the number, the size and the
  height are all correct, so what you build and what you would order are right.
  It is the drawing that is short.

  All four are fixed in the branch this came from,
  watts-j/SangalaBlockDesigner, branch claude/review-brick-library-c92ops.
